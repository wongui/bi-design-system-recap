# Part 2 — Foundations & Tokens

This is the spec to build against once discovery (Part 1) is done. It covers four things, in the order you should actually build them: the token taxonomy, how to calibrate a type ramp to a real audience instead of a default, the foundation build order, and the documentation structure every component should ship with. Skipping ahead — building components before foundations, or documenting after the fact instead of alongside — is the single most common way a design system ends up inconsistent.

## 1. The token taxonomy

Use a consistent, layered naming structure for every token in the system:

```
Color → Purpose → Component → Scope → Variant → State
```

Read left to right, each layer narrows the last:

| Layer | Answers | Example |
|---|---|---|
| **Color** | What's the raw value? | `Green/500` |
| **Purpose** | What role does it play, independent of any component? | `Success`, `Accent`, `Surface` |
| **Component** | Which component consumes it? | `Button`, `Badge`, `Alert` |
| **Scope** | Which part of that component? | `Background`, `Border`, `Text` |
| **Variant** | Which visual variant of the component? | `Solid`, `Soft`, `Outline` |
| **State** | Which interaction state? | `Default`, `Hover`, `Disabled` |

A fully-resolved semantic token name reads like a sentence: *Button / Background / Solid / Hover* is a Component-Scope-Variant-State chain, ultimately pointing at a Purpose-layer color. **Never let a component bind directly to a Color-layer primitive.** Every binding should pass through Purpose at minimum, ideally all the way to a Component-specific semantic token. This is what lets you re-theme, re-brand, or fix a contrast issue in one place instead of hunting down every hardcoded reference.

Build two layers of variables in both code and Figma:
- **Primitives** — the raw palette, spacing scale, radius scale. Nobody outside the token layer itself should ever reference these directly.
- **Semantic** — the Purpose→Component→Scope→Variant→State chain above. Everything else in the system — every component, every doc page — references semantic tokens only.

## 2. Calibrating the type ramp to your actual audience

Don't start from a generic type scale. Start from the audience answer you got in Part 1, and work backwards to numbers:

1. **Set the floor first.** What's the smallest body text size this specific audience can comfortably read? This is the one number every other decision depends on — get it from the discovery answers (age, vision, context of use), not from a framework default.
2. **Set the target size**, above the floor, for the actual primary reading experience (not captions, not labels — the thing people spend most of their time reading).
3. **Set touch/click target minimums** if this is an interactive product, calibrated to the same audience (e.g. an older or motor-impaired audience needs meaningfully larger targets than a general one).
4. **Set a contrast target.** Default to WCAG AA (4.5:1) unless the audience answer justifies going further. A worked example from a real project: a primary audience of 65+ readers, several already managing vision loss, justified a hard **7:1** contrast target — well past AA — because the audience had no headroom for "acceptable but not ideal." That's a *reason-driven* number, not a template default; get your own reason before you copy it.
5. **Build the rest of the ramp (headings, labels, captions) upward and downward from that floor and target**, never below the floor, ever — including in dense UI, tags, or fine print. A design system that puts a 6px legal disclaimer under an 18px floor calibrated for readability isn't actually accessible, it's accessible everywhere except where it mattered.

Write this down explicitly as a short type-ramp spec (floor, target, targets-for-interaction, contrast minimum, and the reasoning behind each) before building a single type style. It's the one foundation decision that's expensive to change later, because everything else gets built relative to it.

## 3. Foundation build order

Build foundations in this order — each one depends on the last:

1. **Brand assets** — logo, brand marks, any licensed fonts (confirm they actually load in your build environment early; font-loading problems surface late otherwise and block everything downstream).
2. **Color** — primitives first, then the semantic layer from step 1 above. If you already know from discovery that this needs to support more than one brand, build a `Foundation/Brand` variable collection **now**, with your first brand as one mode — even if a second brand isn't confirmed yet. Retrofitting brand-switching into an already-built semantic layer is significantly more expensive than starting with it.
3. **Typography** — the ramp from step 2 above, as real text styles (not just CSS variables) — every text style should be a named, reusable object, not a one-off font-size declaration repeated across components.
4. **Spacing & layout** — a consistent spacing scale (not arbitrary pixel values per component) and a grid/layout system.
5. **Icons** — a complete, consistently-styled icon set, organized as its own component family (this matters later: the Figma translation step wires icon props to a real instance-swap property, which needs the icon set to already exist as a proper component set).

Only after these five are solid should component work start.

## 4. Component family organization

Organize components into families from the start, rather than growing a flat, ungrouped list. A pattern that's worked well across projects:

- **Foundations** — brand assets, colors, typography, spacing & layout, icons (the five above, represented as their own documented "components" even though they're not UI elements).
- **Display** — avatars, badges, accordions, anything primarily informational.
- **Navigation** — nav bars, tabs, footers.
- **Feedback** — alerts, progress indicators, modals, trackers, chips — anything communicating status or interrupting the user.
- **Actions** — buttons, icon buttons — anything primarily about triggering something.
- **Cards** — composite content containers (general cards, resource cards, detail cards, etc.) — usually the first layer where components start being built *from* other components.
- **Forms** — inputs, text areas, checkboxes, selects, switches — anything collecting input.

This isn't a fixed taxonomy — adjust the families to your actual component list — but pick a small, memorable set of families early and stick to it. It's the difference between a system someone can navigate by intuition and one that requires a search bar to use.

## 5. Documentation structure — every component, no exceptions

Every component should ship a fixed set of documentation sections, in this order, and none of them should ever contain placeholder mockups standing in for the real thing:

| Section | What it shows | Why it exists |
|---|---|---|
| **Demo** | The real, live component — not a screenshot, not a static mockup — in its default and a few representative states. | Anyone landing on the page should see the actual thing working, immediately. |
| **Code** | The actual usage snippet — copy-pasteable, matching what the demo above is running. | Removes the gap between "here's what it looks like" and "here's how you'd actually use it." |
| **Anatomy** | A labeled breakdown of the component's parts (e.g. icon slot, label, container) and which tokens each part consumes. | This is what makes the Figma translation step possible later — it's the map from code structure to visual structure. |
| **Specimen matrix** | Every meaningful variant × state combination, laid out as a real grid — not a curated highlight reel. | If a combination isn't shown here, nobody building with the system will know it exists or looks right. |
| **Component properties** | The full prop/variant contract in plain language — what each prop does, its accepted values, its default. | The reference someone checks before writing code, not after something breaks. |
| **Tokens consumed** | The explicit list of every token this component references. | Makes it possible to answer "what would break if I changed this token?" without grepping the codebase. |

**A doc page with a placeholder mockup instead of a live component is worse than no doc page** — it actively misleads anyone trusting it as the source of truth. If a component genuinely doesn't exist yet, say so plainly on its doc page rather than faking a demo. Audit for this explicitly before considering the system "documented" — it's an easy thing to let slip past review, because a good-looking placeholder is easy to mistake for done.

## Definition of done, per component

Before calling any individual component finished:
- [ ] Every fill, stroke, radius, spacing, and type choice traces back to a semantic token — zero hardcoded values.
- [ ] Every documented variant × state combination actually exists in the code, and vice versa (no undocumented variants, no documented-but-unbuilt ones).
- [ ] The doc page's Demo section is the real, live component.
- [ ] Anatomy, Specimen Matrix, Component Properties, and Tokens Consumed sections are all filled in — not stubbed.
- [ ] Accessibility basics hold at the component level (contrast against the type-ramp spec, real focus states, keyboard operability if interactive).

Once a meaningful slice of components clears this bar and the token/type/spacing foundations are stable, move to [`03-figma-translation.md`](03-figma-translation.md).
