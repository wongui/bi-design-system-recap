# The frog Design System Starter Kit

A practical, three-part guide for standing up a new design system with Claude — from a blank repo to a working, documented, Figma-translated library. This isn't theory. It's the actual sequence, prompts, structure, and hard-won gotchas from building a real multi-brand, accessibility-first design system end to end, generalized so any frog team can reuse it on the next one.

## What's in here

| File | What it's for | When you use it |
|---|---|---|
| [`01-kickoff-and-discovery.md`](01-kickoff-and-discovery.md) | A prompt you run **first**. It has Claude read everything already in your project folder, then ask you the questions that actually determine how the system should be built — who it's for, who it's client for, what "done" looks like — and turn your answers into a build plan. | Day one, before any code exists. |
| [`02-foundations-and-tokens.md`](02-foundations-and-tokens.md) | The spec for the system itself: token taxonomy, how to calibrate a type ramp to your actual audience, foundation build order, component family organization, and the documentation page structure (Demo, Code, Anatomy, Specimen Matrix) every component should ship with. | While you and Claude are building the system in code. |
| [`03-figma-translation.md`](03-figma-translation.md) | How to get a code-built system into Figma without it silently drifting — what to set up first, what *not* to try (three real dead ends, explained), and the `/build-figma-component` command that actually works, ready to drop into your own project. | Once the code system has a stable token/style foundation and at least a few real components. |

Plus: `.claude/commands/build-figma-component.md` — the actual slash command referenced in part 3, ready to copy into your own repo.

## How to actually use this

1. **Start a new project folder.** Drop in whatever you already have — brand guidelines, old product screens, research decks, a rough new direction. Don't organize it first; the kickoff prompt is built to read a messy folder.
2. **Run the prompt in `01-kickoff-and-discovery.md`.** Answer its questions honestly, even the ones that feel obvious. The plan it produces is only as good as what you tell it about the client, the users, and what "good" looks like for this specific project.
3. **Build the system in code first**, using `02-foundations-and-tokens.md` as your spec while you go. Don't skip to Figma. A system that isn't solid in code will just be *wrong*, faster, in Figma.
4. **Translate to Figma with `03-figma-translation.md`** once the code side has real components with real tokens behind them. Read the "what didn't work" section before you try anything — it'll save you the same three dead ends we already hit.
5. **Expect to keep a hand on it.** Every part of this kit is built to move fast on the mechanical parts — token binding, variant matrices, repetitive builds — and to explicitly stop and ask you for the calls that are actually judgment: accessibility trade-offs, brand nuance, what a client will and won't accept. That split is the point, not a limitation to work around.

## Where this came from

Built out of a real project: a healthcare patient-portal design system, built for a 65+ primary audience, that grew into a two-brand token system with 24+ components across six families, fully documented, and translated into Figma through a component-build pipeline that took three failed attempts before it held. The specifics in this kit have been generalized — swap in your own client, audience, and brand details — but the process, the ordering, and the gotchas are all real.

## A note on tone

Everything in this kit is written the way we'd actually want a design system to talk to its own users: plain language, no unnecessary jargon, honest about what's still manual. Keep that going in whatever you build with it — it's as much a part of "accessibility first" as the type ramp is.
