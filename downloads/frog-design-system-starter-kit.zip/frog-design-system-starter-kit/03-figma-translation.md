# Part 3 — Translating the System into Figma

This is the last step, not the first — only start here once the code side has a stable token/type/spacing foundation (Part 2) and at least a handful of real, documented components. Trying to translate to Figma before the code foundation is stable just moves the instability into a second place you now have to keep in sync.

## Set up the Figma side of the foundation first

Before building a single component in Figma, make sure the file already has:
- **A semantic variable layer** mirroring your code's Purpose→Component→Scope→Variant→State taxonomy — not just a palette of raw colors.
- **Native text styles** for every rung of your type ramp, named clearly enough that they're findable by search.
- **A complete `Icon` component set**, if any components use icon slots — this needs to exist before any component can wire an instance-swap property to it.
- **A brand variable collection** with a mode per brand, if Part 1's discovery surfaced a multi-brand need — set this up even before the second brand is confirmed; it's much cheaper now than later.

The command in this guide *builds onto* this foundation. It does not create it. If it's missing, build it first — by hand, or by asking Claude to help you construct it directly in Figma via the MCP tools, one variable collection and text style set at a time.

## What doesn't work — three dead ends worth skipping

Before landing on the component-at-a-time approach below, three other approaches got tried on a real project. All three were eventually abandoned. Save yourself the time:

1. **A plugin that pushes tokens from code into Figma.** Works the moment you build it, then quietly drifts the first time the token structure changes on either side — nothing forces the plugin and the token layer to stay in agreement, so it goes stale without announcing it.
2. **A second plugin, built with more Figma-native tooling.** Same wall, different door — the underlying problem (nothing verifies the two sides still match) doesn't go away just because the plugin was built differently.
3. **A full-file regeneration tool** (the "point it at a prompt and it rebuilds the whole UI" style of tool). Fast to a plausible-looking UI, but it doesn't preserve real token bindings or the accessibility precision already built into the code — you get something that *looks* like your system without actually *being* bound to it.

The common failure mode across all three: each tried to move fast by working on the whole system (or a whole plugin) at once, with no built-in way to verify the result actually still matches the source. The approach that held up instead works on **one component at a time**, resolves every value to a real token or style (never a guess), and **verifies itself against the component's own documentation before calling it done.** Slower per component. Doesn't drift.

## The command

Copy `.claude/commands/build-figma-component.md` from this kit into your own project at the same path. Fill in the four placeholders at the top (`{{FIGMA_FILE_NAME}}`, `{{FIGMA_FILE_KEY}}`, `{{LIBRARY_KEY}}`, `{{COMPONENT_SOURCE_GLOB}}`) and adjust the "read the source of truth" step to match your repo's actual file convention — the doc-page structure from Part 2 is what this command leans on most, so the closer your docs follow that structure, the less adjustment this needs.

```
/build-figma-component Badge
/build-figma-component Badge Components/Display
/build-figma-component Badge 145:2
/build-figma-component Badge https://figma.com/design/<key>/...?node-id=139-2
```

First argument is the component name, matched against your source files. The optional second argument is where to build it in Figma — leave it off and Claude will list the file's pages and ask, rather than guessing.

What it actually does, in short: reads the component's real source and doc page, resolves every token and text style to the file's actual semantic layer (never a raw primitive, never a hand-set font size), builds real Figma variant properties for every prop combination, wires icon/boolean props to real component properties, lays the variant set out as a measured, scannable grid instead of a messy stack, and finishes by checking its own work against the doc page and telling you exactly what didn't map cleanly. Full step-by-step detail is in the command file itself.

### Don't want to fill in placeholders by hand?

Paste this into Claude Code at the root of your own project instead, and it'll write you a customized version from scratch:

```
I want a Claude Code slash command called /build-figma-component that builds a real,
fully-bound component in Figma from this repo's own source of truth — not a rough visual
copy. First, inspect my repo to find how components are actually organized here
(implementation files, type contracts, doc pages, usage examples — whatever really
exists), and tell me the pattern you find. Then ask me for my Figma file's name, file
key, and its own published-library key (look the library key up yourself via the Figma
MCP if you're connected, rather than asking me to find it). Confirm the file already has
a semantic variable layer, native text styles, and an Icon component set before going
further — this command builds onto an existing foundation, it doesn't create one. Then
write the command to .claude/commands/build-figma-component.md, keeping these lessons in
it: token resolution must be scoped to the file's own library key or it can silently
match the wrong variable from another library; typography must always go through native
text styles, never a hand-set font/size, and a missing style match should be reported as
a gap rather than faked; every fill/stroke/radius must be a bound variable and every enum
prop a real variant axis; icon props become real instance-swap properties; the variant
grid must be laid out from actual measured widths/heights as real rows and columns, not
guessed or left in whatever order the tool produced; component sets clip their content
and don't auto-grow when children move outside the original bounds, so the set must be
explicitly resized and un-clipped after laying out the grid; labels must be separate
nodes outside the component set, grouped with it only long enough to screenshot both
together, then ungrouped; and the build must end by verifying itself against the doc
page and reporting exactly what mapped cleanly versus what needed a fallback. Show me the
result and confirm the details it inferred are right before I try running it.
```

## What still won't be automatic — and that's fine

Once components start landing in Figma, two things stay genuinely manual, and planning for that up front avoids the feeling that something's broken when it happens:

- **Restructuring an existing component can silently break it in ways that look fine at a glance.** Adding or reorganizing parts of a component set can orphan its property references even when the property *definitions* still look correct — the only reliable catch is a manual before/after diff, not a visual check. Get in the habit of diffing structural changes, not just eyeballing them.
- **Full screens are push-then-refine, not push-and-done.** Once enough components exist in Figma, assembling a documentation page or a whole screen from them goes fast — but spacing, real content, edge cases, and interaction nuance still need a human pass, screen by screen. Budget time for this explicitly; it's not a sign the pipeline failed, it's the actual shape of the work.

And some decisions should simply never be automated at all — a color choice that exists specifically so a state doesn't rely on color alone for colorblind users, for instance, is a judgment call informed by the accessibility work in Part 2, not a mismatch for a "fix the contrast" pass to correct. Know the difference between a drift you should fix and a decision you should defend.
