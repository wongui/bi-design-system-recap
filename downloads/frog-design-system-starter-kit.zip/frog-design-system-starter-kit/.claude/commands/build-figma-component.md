---
description: Build/rebuild a component in your Figma design system file, matching your codebase's source of truth exactly
argument-hint: <ComponentName> [target page name | node-id | figma.com URL]
---

<!--
  SETUP — fill these in for your own project before using this command:

  {{FIGMA_FILE_NAME}}      e.g. "Design System V1"
  {{FIGMA_FILE_KEY}}       the key from your Figma file's URL: figma.com/design/<KEY>/...
  {{LIBRARY_KEY}}          this file's own published-library key (Figma MCP: search_design_system
                           result metadata, or ask Claude to look it up once and paste it in here)
  {{COMPONENT_SOURCE_GLOB}} where your component source lives, e.g.
                           "src/components/**/<ComponentName>.tsx"

  Then adjust "1. Read the source of truth" below to match YOUR repo's actual file
  convention — the four-file quartet (impl / type-contract / doc-page / usage-notes) is
  just one common shape. If your repo uses Storybook stories, MDX docs, or a single
  file per component, list whatever your equivalents are instead.

  Delete this comment block once configured.
-->

Arguments given: $ARGUMENTS

Parse the arguments above: the first whitespace-separated token is the **component name**. Everything after it (if anything) is the **target page/location** — it may be a bare page name, a raw node-id like "145:2", or a full figma.com URL. If a figma.com URL is present, treat the whole URL (not just its first token) as the target location even though it contains no spaces itself — don't split it further.

Build that component in Figma, matching the code source in this repo exactly.

Target Figma file: `{{FIGMA_FILE_NAME}}`, key `{{FIGMA_FILE_KEY}}`.

If no target location was given: run `get_metadata` on the file, list the current top-level pages, and ask me which page to build on (or whether to create a new page) before doing anything else. Don't guess.
If the target location is a figma.com URL: extract the node-id from its `node-id=` query param (converting `-` to `:`, e.g. `139-2` → `139:2`) and resolve that node via `get_metadata` — confirm what you resolved it to before building.
If the target location is a bare name (e.g. "Badge", "Components/Forms"): find the matching page by name via `get_metadata`; if more than one page matches, ask which.
If the target location is a raw node-id (e.g. "145:2"): use it directly.

## 1. Read the source of truth
Before touching Figma, read all of, for the named component:
- `{{COMPONENT_SOURCE_GLOB}}` — actual styling logic, every prop and its token
- its type contract (e.g. `.d.ts`, PropTypes, or equivalent) — full prop/variant contract
- its doc page, if one exists — anatomy, variant matrix, sizes
- its usage examples/notes, if any — canonical usage

List every distinct token referenced (color, typography, radius, spacing, border) and every variant axis (tone, variant, size, state, icon slot). If any of these don't exist for the component, tell me which are missing and proceed with what's available rather than inventing behavior.

## 2. Resolve each token to its Figma equivalent
In file `{{FIGMA_FILE_KEY}}`:
- Use `get_variable_defs` / `search_design_system` to find the matching semantic variable for each color/spacing/radius var used in the source. `search_design_system` mixes in results from every other published library on the account — always pass `includeLibraryKeys` scoped to this file's own library key (`{{LIBRARY_KEY}}`) or cross-check hits against a direct `figma.variables.getLocalVariablesAsync()` name search via `use_figma`, otherwise you will miss real local variables and wrongly reuse an unrelated token instead — never bind two different variants to the same variable unless the source code genuinely uses the same value for both.
- Prefer semantic tokens over primitives always. If a token only maps to a raw primitive in Figma (a common gotcha: on-canvas components sometimes bind fills directly to primitives instead of the semantic layer), flag it back to me rather than silently binding to the primitive.
- **Always use the file's actual native text styles for typography — never hand-set `fontName`/`fontSize` as a substitute.** Pull the full list via `figma.getLocalTextStylesAsync()` in a `use_figma` call and match by name/size/weight to the source's type token. Apply the match with `await node.setTextStyleIdAsync(style.id)`, not manual property assignment — this keeps the text linked to the style so future ramp edits cascade. If no existing style matches the source's exact size+weight combination, do NOT fake it with a manual override or a different family/weight — tell me the gap explicitly (e.g. "no 14px/medium style exists; closest is Label/Meta at 14px/regular") and let me decide whether to add a new style or accept the closest match.
- If your brand uses a licensed/custom font, its availability in the Figma runtime can vary session to session — don't assume it's blocked just because a prior session failed. Test with a throwaway `loadFontAsync` call for the exact family+style before committing to a build that depends on it; if it fails, tell me rather than guessing a substitute font.

## 3. Build with real bindings, not hardcoded values
- Auto layout matching the source's flex/gap/padding exactly, using bound spacing/radius variables — not literal pixel values.
- Every fill/stroke/corner-radius bound to a variable — zero hardcoded hex or unbound radii.
- Every text node's typography bound to a native text style (per step 2) — zero manually-set font/size pairs standing in for a style.
- Component **variant properties** for every enum prop in the type contract (e.g. tone × variant × size), produced as one proper Figma component set — not separate unlinked frames.

## 4. Wire up any icon or swappable slot as a real property
- Find the existing `Icon` component set in the file (search pages/frames for "Icon").
- Any prop that renders an icon becomes an **instance-swap property** on the component, defaulting to whatever the code's example shows, but selectable to any icon in that set.
- Boolean/optional slots (icon-or-none) become a boolean property that shows/hides the instance.

## 5. Organize the variant grid for scannability
Don't leave the finished component set in whatever order `combineAsVariants` happened to produce (usually one long row/column). Lay it out as a real 2D matrix, plus labels alongside it — same pattern as the file's own doc pages (tone rows × soft/solid columns, etc.):

- **Pick the grid axes.** Rows = the variant axis with the most semantically distinct values (tone, state, variant — whichever groups most naturally by row in your anatomy doc). Columns = the remaining axes, nested: a primary grouping (e.g. soft/solid) each split into sub-columns (e.g. sm/md) if there's a third axis. Two axes → simple rows × columns; three axes → rows × grouped-columns as above; ask me if the right grouping isn't obvious.
- **Compute layout from real measurements, not guesses.** In one `use_figma` call: index all variant children by name, measure each one's actual `width`/`height` (they vary — text length differs per tone, sm/md differ in padding), compute each column's width as the max width of any variant in that column and each row's height as the max height of any variant in that row, then position every child at the cumulative offset for its column/row (centering it within the cell). Use consistent gaps (e.g. 24–32px between column groups, 16–20px between rows).
- **Resize the component set and disable clipping after repositioning.** Component sets clip their content by default and do NOT auto-grow when you move children outside the original bounds — if you skip this, everything past the original bounding box silently disappears. After repositioning, explicitly `set.resizeWithoutConstraints(maxChildRight + pad, maxChildBottom + pad)` and set `set.clipsContent = false`, computed from the children's actual post-layout positions.
- **Add labels as separate nodes outside the component set** (component sets can only contain variant components, not arbitrary text) — column group headers, per-column sub-labels (e.g. sm/md), and row labels (e.g. tone names), positioned using the same column/row offsets, anchored relative to the set's own `x`/`y`. Use real native text styles for these labels too (e.g. an overline/label style for headers, per step 2's rule) — they're canvas annotations for scanability, not part of the component itself, but they should still look native to the system.
- **To screenshot the set + its labels together for verification**, `node.screenshot()` only renders within a node's own frame — grouping the set and label nodes together with `figma.group()` (which preserves absolute position, unlike `appendChild`) lets you screenshot the group as one image; `figma.ungroup()` it back afterward so the component set returns to being a normal top-level node, not trapped inside a generic group.

## 6. Verify before calling it done
- Screenshot / `get_design_context` the finished component set and confirm it visually matches your doc page.
- Spot-check `get_variable_defs` on a few new node IDs to confirm nothing is unbound.
- Spot-check that text nodes carry a real `textStyleId`, not a manually-set font/size.
- Confirm no two semantically-distinct variants (e.g. different tones) were bound to the identical variable — that's a sign a token was missed or mismatched, not that the source really intends them to look the same.
- Confirm every variant combination in the code's prop matrix has a matching Figma variant — no missing combinations, no extras.
- Confirm the variant grid is organized per step 5 (real rows/columns, not a single strip) and that resizing + disabling clipping actually took effect (re-check the set's width/height against its children's bounds).
- Report back: which tokens mapped cleanly, which fell back to a primitive (and why), which text styles couldn't be matched exactly (and what the closest one was), how the grid was organized (which axis became rows vs. columns), and the page/node the component now lives on.
