# Part 1 — Kickoff & Discovery

Every design system that drifts, over-scopes, or ships the wrong defaults usually went wrong here, on day one — not in the token structure or the Figma build. This part exists so Claude asks the questions a senior designer would ask before opening Figma, instead of guessing from a folder of assets and a vague "build us a design system."

## How to use this

1. Start a **new, empty repo** (or a folder — code doesn't need to exist yet).
2. Drop in whatever you already have, unsorted: brand guidelines, old product screens, a competitor teardown, research decks, a rough new direction someone sketched. The prompt is built to read a messy folder — don't tidy it first.
3. Open Claude Code in that folder, ideally in **Plan mode** (so it researches and asks before it starts creating files).
4. Paste the prompt below as your first message.
5. Answer its questions for real. Vague answers produce a vague plan — this step is where the whole project gets calibrated, not a formality before the "real" work starts.

---

## The prompt

```
I want to build a new design system for a client project, starting from scratch (or from
what's already in this folder — check first). Before you propose anything or write a
single file, do this in order:

1. READ EVERYTHING ALREADY HERE.
   Go through this project folder end to end: brand guidelines, style references, old
   product screens, research decks, briefs, competitor examples, anything. Summarize
   back to me what you found and what it tells you — don't just list filenames, tell me
   what each thing implies about the brand, the audience, or the constraints.

2. ASK ME THE QUESTIONS THAT ACTUALLY MATTER, before proposing a plan. Specifically:

   About the client and the brand:
   - Who is this system for — client name, and is there an existing brand system (a
     global/parent design system, brand guidelines, an existing component library) this
     new one needs to connect to, inherit from, or stay consistent with?
   - Is there more than one brand or product line this system needs to serve now or
     later? (This changes the token architecture from day one — it's much cheaper to
     plan for it up front than to retrofit it in later.)
   - Is there a name for the product/experience this system will power?

   About the people who will actually use what gets built with it:
   - Who is the primary user — age range, general tech comfort, and the emotional or
     physical context they'll likely be in when using it (e.g. calm and exploring vs.
     stressed, in pain, in a hurry, low vision, using it one-handed)? Be specific — "adults"
     is not specific enough to calibrate a type ramp or an interaction pattern against.
   - Are there secondary user types (caregivers, admins, clinicians, internal staff) who
     also touch this system, and do their needs conflict with the primary user's?
   - What devices/platforms matter most — mobile-first, desktop-first, both equally,
     something else (kiosk, tablet-in-clinic, etc.)?

   About constraints that change how the system should be built:
   - Does this project touch regulated or sensitive data (health information, financial
     data, anything that might fall under HIPAA, GDPR, PCI-DSS, or similar)? If yes, say
     so explicitly — flag it back to me and recommend I loop in Legal/Compliance/the Data
     Privacy Officer before we lock in any pattern that touches that data. Don't try to
     resolve compliance questions yourself.
   - Are there existing accessibility requirements or targets (WCAG level, a specific
     contrast ratio, an internal a11y standard) — or should we set our own based on the
     primary user answer above?
   - Is there a hard deadline, a fixed component scope, or a "must ship these N screens
     by X" constraint that should shape sequencing?

   About what "done" looks like:
   - Is the deliverable code, Figma, or both? If both, which comes first, and does the
     other need to stay in sync afterward (one-time translation vs. an ongoing pipeline)?
   - Who's the audience for the finished system — will other designers/engineers use it
     day to day, or is this mostly for one team's own build?

   Ask these as an actual conversation, not a form — if my answer to one question
   changes what a later question even means, follow that thread before moving on.

3. ONLY AFTER I've answered, synthesize everything (the files you read + my answers)
   into a short written project brief, then a phased build plan. The plan should
   reference the other two guides in this kit — foundations/tokens first, Figma
   translation only once the code side is stable — and should call out anywhere my
   answers create an unusual requirement worth flagging (e.g. an aggressive type-ramp
   floor because of the audience, or a token architecture that needs to support N brands
   from day one instead of one).

Do not start building components, tokens, or files until I've confirmed the brief and
plan look right.
```

---

## What good answers look like

A vague answer here doesn't just produce vague copy later — it produces the wrong *architecture*. Two examples of the difference:

- **"Our users are adults."** vs. **"Primary users are 60–85, often managing a new chronic diagnosis, frequently anxious, sometimes using the product one-handed while also holding a phone call with a family member."** The second answer is what actually justifies a 7:1 contrast target, an 18px body floor, and a calmer, less-cluttered interaction model — not a generic "make it accessible" instruction.
- **"Just this one brand for now."** vs. **"Just this one brand for now, but the client has three other product lines that could plausibly get their own portal in the next two years."** The second answer is the difference between a token architecture with a `Foundation/Brand` layer built in from day one, and a painful retrofit later.

If you don't know an answer yet (e.g. the client hasn't confirmed a second brand), say that — "unconfirmed, treat as possible" is itself useful input, and different from "no."

## What comes out of this

By the end of this step you should have: a short written brief Claude can refer back to throughout the project, and a phased plan that already accounts for your actual audience, brand structure, and constraints — not a generic "design system starter" template with your logo swapped in. That plan is what carries you into [`02-foundations-and-tokens.md`](02-foundations-and-tokens.md).
